'use client';

import { useState } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import Sidebar from '@/components/shared/Sidebar';
import { useGetTrackOrderByInvoiceIdMutation } from '@/redux/features/Order/ordersApi';
import { useGetTrackCustomBazarOrderByInvoiceIdMutation } from '@/redux/features/CustomBazar/customBazarApi'; // ✅ create or use correct hook
import { Button } from '@/components/ui/button';

export default function TrackOrderPage() {
  const [invoiceNumber, setInvoiceNumber] = useState('');

  // Normal Order API
  const [trackOrder, { data: orderData, isLoading: orderLoading, error: orderError }] =
    useGetTrackOrderByInvoiceIdMutation();

  // Custom Bazar Order API
  const [trackCustomOrder, { data: customOrderData, isLoading: customLoading, error: customError }] =
    useGetTrackCustomBazarOrderByInvoiceIdMutation();

  const order = orderData?.data 
  const customOrder =  customOrderData?.data;
  const isLoading = orderLoading || customLoading;
  const error = orderError || customError;

  const handleSearch = async () => {
    if (invoiceNumber.trim() === '') return;

    // Try normal order first
    const res = await trackOrder(invoiceNumber.trim());

    // If not found, try custom order
    if (!res?.data) {
      await trackCustomOrder(invoiceNumber.trim());
    }
  };

  return (
    <ProtectedRoute>
      <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r">
          <Sidebar />
        </div>

        {/* Main Content */}
        <div className="flex-1 flex justify-center items-start p-4 sm:p-6">
          <div className="w-full max-w-xl bg-white rounded-lg shadow-md p-6 sm:p-8">
            <h1 className="text-2xl sm:text-3xl font-bold mb-6 text-center">
              Track Your Order
            </h1>

            <div className="mb-6">
              <label
                htmlFor="invoice"
                className="block font-semibold mb-2 text-gray-700"
              >
                Invoice Number
              </label>
              <input
                id="invoice"
                type="text"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                placeholder="Enter your invoice number"
                className="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
              />
              <Button
              variant={"secondary"}
                onClick={handleSearch}
                className="mt-4 w-full "
                disabled={isLoading}
              >
                {isLoading ? 'Searching...' : 'Search'}
              </Button>
            </div>

          {/* Error */} 
{!order && !customOrder && error && (
  <p className="text-red-600 text-center mt-4">
    Order not found or error occurred. Please check the invoice number.
  </p>
)}

{/* Order Info */}
{(order || customOrder) && (
  <div className="mt-6 border-t pt-4 space-y-2 text-gray-800">
    <p>
      <strong>Status:</strong>{' '}
      <span className="capitalize">
        {order ? order.orderStatus : customOrder?.status}
      </span>
    </p>

    <p>
      <strong>Created At:</strong>{' '}
      {new Date(
        order ? order.createdAt : customOrder?.createdAt
      ).toLocaleString()}
    </p>
    <p>
      <strong>Last Updated:</strong>{' '}
      {new Date(
        order ? order.updatedAt : customOrder?.updatedAt
      ).toLocaleString()}
    </p>
  </div>
)}

          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}
